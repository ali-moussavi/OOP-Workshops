
#include "Utils.h"

using namespace std;

namespace sdds {
	//a hepler function that trims whitespace from beginnig and end of strings
	string trim(const string& str)
	{
		const size_t strBegin = str.find_first_not_of(" ");
		if (strBegin == string::npos)
			return ""; // no content

		const size_t strEnd = str.find_last_not_of(" ");
		const size_t strRange = strEnd - strBegin + 1;

		return str.substr(strBegin, strRange);
	}
}