#pragma once
#include <iostream>
#include <string>


using namespace std;

namespace sdds {

	class Movie
	{
	public:
		Movie();
		Movie(const std::string& strMovie);
		~Movie();
		const std::string& title() const;
		template<typename T>
		void fixSpelling(T spellChecker) {
			spellChecker(m_title);
			spellChecker(m_description);
		}
		friend ostream& operator<<(ostream& os, const Movie& m);

	private:
		string m_title;
		size_t m_year;
		string m_description;
	};

}