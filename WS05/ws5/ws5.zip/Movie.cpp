#include <iomanip>
#include "Movie.h"
#include "Utils.h"
using namespace std;

namespace sdds {

	

	Movie::Movie()
	{
		m_title = "";
		m_description = "";
		m_year = 0;
	}

	Movie::Movie(const std::string& strMovie)
	{
		string temp = strMovie;

		m_title = trim(temp.substr(0, temp.find(','))).c_str();
		temp.erase(0, temp.find(',') + 1);
		m_year = stoi(trim(temp.substr(0, temp.find(','))));
		temp.erase(0, temp.find(',') + 1);
		m_description = trim(temp);
	}

	Movie::~Movie(){

	}
	const std::string& Movie::title() const
	{
		return m_title;
	}

	ostream& operator<<(ostream& os, const Movie& m)
	{
		os << setw(40) << right << m.m_title << " | " << setw(4) << m.m_year <<
			" | " << m.m_description << endl;

		return os;
	}
}