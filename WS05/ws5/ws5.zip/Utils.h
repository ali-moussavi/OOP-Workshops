#pragma once
#include <iostream>
#include <string>
using namespace std;

namespace sdds {
	string trim(const string& str);
}